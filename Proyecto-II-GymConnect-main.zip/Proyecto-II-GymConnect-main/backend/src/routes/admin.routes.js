import express from 'express';
import User from '../models/User.js';
import ProfesorRequest from '../models/ProfesorRequest.js';
import { verifyToken, verifyAdmin } from '../middlewares/authMiddleware.js';
import { 
  verificarIdSeguro, 
  generarIdSeguro,
  decorarRespuestaConIdsSeguros 
} from '../middlewares/seguridadMiddleware.js';
import { enviarEmailAprobacion } from '../config/email.js';
import bcrypt from 'bcrypt';

const router = express.Router();

// Middleware para todas las rutas admin que usan IDs
const validarRutasConId = [verifyToken, verifyAdmin, verificarIdSeguro];

// Obtener todos los usuarios - ADMIN ONLY
router.get('/usuarios', verifyToken, verifyAdmin, async (req, res) => {
  try {
    console.log('🔧 Admin obteniendo usuarios, rol:', req.usuario_rol);
    
    const usuarios = await User.findAll({
      attributes: ['id', 'nombre', 'email', 'rol', 'telefono', 'createdAt'],
      raw: true,
    });
    
    console.log('📦 Usuarios crudos de BD:', usuarios);
    
    const usuariosDecorados = usuarios.map(usuario => {
      // Función para calcular dígito
      const calcularDigitoVerificador = (id) => {
        const strId = id.toString();
        let suma = 0;
        
        for (let i = 0; i < strId.length; i++) {
          const digito = parseInt(strId[i], 10);
          const multiplicador = (i % 2 === 0) ? 3 : 7;
          suma += digito * multiplicador;
        }
        
        return (suma % 10).toString();
      };
      
      // Solo modificar si existe id
      if (usuario.id !== undefined && usuario.id !== null) {
        const idNum = parseInt(usuario.id, 10);
        if (!isNaN(idNum)) {
          const digito = calcularDigitoVerificador(idNum);
          console.log(`   🔢 ID ${idNum} → dígito: ${digito}`);
          return {
            ...usuario,
            id: `${idNum}-${digito}`
          };
        }
      }
      
      return usuario;
    });
    
    console.log('🎨 Usuarios decorados:', usuariosDecorados);
    
    res.json(usuariosDecorados);
  } catch (error) {
    console.error('💥 Error en /usuarios:', error);
    res.status(500).json({ error: error.message });
  }
});

// Obtener solicitudes de profesor - ADMIN ONLY
router.get('/solicitudes-profesor', verifyToken, verifyAdmin, async (req, res) => {
  try {
    console.log('🔧 Admin obteniendo solicitudes, rol:', req.usuario_rol);
    const solicitudes = await ProfesorRequest.findAll({
      include: [
        {
          model: User,
          as: 'usuario',
          attributes: ['id', 'nombre', 'email'],
          required: false,
        },
      ],
      order: [['createdAt', 'DESC']],
    });
    
    // Decorar IDs de usuario en las solicitudes
    const solicitudesDecoradas = decorarRespuestaConIdsSeguros(solicitudes, ['id', 'usuario_id']);
    
    res.json(solicitudesDecoradas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Aprobar solicitud de profesor - CON VALIDACIÓN DE ID SEGURO
router.post('/aprobar-profesor/:id', ...validarRutasConId, async (req, res) => {
  try {
    const idBase = req.idValidado.base; // Usar ID validado
    console.log('🔧 Aprobando solicitud (ID seguro):', req.idValidado.completo);
    
    const solicitud = await ProfesorRequest.findByPk(idBase, {
      include: [
        {
          model: User,
          as: 'usuario',
          attributes: ['id', 'nombre', 'email'],
          required: false,
        },
      ],
    });

    if (!solicitud) {
      return res.status(404).json({ 
        error: 'Solicitud no encontrada',
        idRecibido: req.idValidado.completo
      });
    }

    console.log('📧 Datos solicitud:', {
      nombre: solicitud.nombre,
      email_personal: solicitud.email_personal,
      usuario_id: solicitud.usuario_id
    });

    // Generar contraseña temporal
    const passwordTemporal = 'GymConnect2024';
    const hashedPassword = await bcrypt.hash(passwordTemporal, 10);

    let usuario;

    if (solicitud.usuario_id) {
      // Usuario ya existe, solo actualizar rol
      usuario = await User.findByPk(solicitud.usuario_id);
      if (usuario) {
        usuario.rol = 'profesor';
        await usuario.save();
        console.log('✅ Usuario actualizado a profesor:', usuario.id);
      } else {
        // Crear nuevo usuario si no existe
        usuario = await User.create({
          nombre: solicitud.nombre,
          email: solicitud.email_personal,
          password: hashedPassword,
          rol: 'profesor',
          telefono: solicitud.telefono || null,
        });
        console.log('✅ Nuevo usuario creado:', usuario.id);
      }
    } else {
      // Crear nuevo usuario
      usuario = await User.create({
        nombre: solicitud.nombre,
        email: solicitud.email_personal,
        password: hashedPassword,
        rol: 'profesor',
        telefono: solicitud.telefono || null,
      });
      console.log('✅ Nuevo usuario creado:', usuario.id);

      // Actualizar la solicitud con el usuario creado
      solicitud.usuario_id = usuario.id;
    }

    // Actualizar estado
    solicitud.estado = 'aprobada';
    await solicitud.save();

    // ENVIAR EMAIL
    try {
      await enviarEmailAprobacion({
        nombre: usuario.nombre,
        email_personal: solicitud.email_personal,
        email_corporativo: usuario.email,
        password_temporal: passwordTemporal,
      });
      console.log('✅ Email enviado correctamente a:', solicitud.email_personal);
    } catch (emailError) {
      console.error('❌ Error enviando email:', emailError.message);
    }

    // Decorar respuesta con ID seguro
    const respuestaDecorada = decorarRespuestaConIdsSeguros({
      message: 'Solicitud aprobada exitosamente',
      solicitud,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
      },
    });

    res.json(respuestaDecorada);
  } catch (error) {
    console.error('❌ Error aprobando solicitud:', error);
    res.status(500).json({ 
      error: 'Error aprobando solicitud: ' + error.message 
    });
  }
});

// Rechazar solicitud de profesor - CON VALIDACIÓN DE ID SEGURO
router.post('/rechazar-profesor/:id', ...validarRutasConId, async (req, res) => {
  try {
    const idBase = req.idValidado.base; // Usar ID validado
    console.log('🔧 Rechazando solicitud (ID seguro):', req.idValidado.completo);
    
    const solicitud = await ProfesorRequest.findByPk(idBase);

    if (!solicitud) {
      return res.status(404).json({ 
        error: 'Solicitud no encontrada',
        idRecibido: req.idValidado.completo
      });
    }

    solicitud.estado = 'rechazada';
    await solicitud.save();

    // Decorar respuesta con ID seguro
    const respuestaDecorada = decorarRespuestaConIdsSeguros({
      message: 'Solicitud rechazada',
      solicitud
    });

    res.json(respuestaDecorada);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Actualizar usuario - CON VALIDACIÓN DE ID SEGURO
router.put('/usuario/:id', ...validarRutasConId, async (req, res) => {
  try {
    const idBase = req.idValidado.base; // Usar ID validado
    console.log('🔧 Actualizando usuario (ID seguro):', req.idValidado.completo);
    
    const { rol, nombre, email, telefono } = req.body;

    const user = await User.findByPk(idBase);
    if (!user) {
      return res.status(404).json({ 
        error: 'Usuario no encontrado',
        idRecibido: req.idValidado.completo
      });
    }

    if (rol) user.rol = rol;
    if (nombre) user.nombre = nombre;
    if (email) user.email = email;
    if (telefono) user.telefono = telefono;

    await user.save();
    
    // Decorar respuesta con ID seguro
    const respuestaDecorada = decorarRespuestaConIdsSeguros({
      message: 'Usuario actualizado',
      user
    });

    res.json(respuestaDecorada);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Eliminar usuario - CON VALIDACIÓN DE ID SEGURO
router.delete('/usuario/:id', ...validarRutasConId, async (req, res) => {
  try {
    const idBase = req.idValidado.base; // Usar ID validado
    console.log('🔧 Eliminando usuario (ID seguro):', req.idValidado.completo);
    
    const user = await User.findByPk(idBase);

    if (!user) {
      return res.status(404).json({ 
        error: 'Usuario no encontrado',
        idRecibido: req.idValidado.completo
      });
    }

    // Proteger contra borrar admin
    if (user.rol === 'admin') {
      return res.status(403).json({ error: 'No se puede eliminar un admin' });
    }

    await user.destroy();
    
    res.json({ 
      message: 'Usuario eliminado exitosamente',
      idEliminado: req.idValidado.completo
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;